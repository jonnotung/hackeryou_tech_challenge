

$(function() {

	$('.post_carousel').flickity ({
		watchCSS: true,
		contain: true,
		wrapAround: true
		// fullscreen: true
		// adaptiveHeight: true
	});
});